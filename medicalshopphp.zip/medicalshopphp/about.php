<html>
<head>
<?php include "header.php"; ?>

</head>
<body>
<?php include "nav1.php"; ?>

<div class="container" style = "margin-top : 150px">
      <h2 class = text-center style = "font-family : 'Monotype Corsiva' ; color : #E6120E">About Us</h2>
	  <br><br>
      <div class="row">
          <div class="col-sm-4 text-center">
              <img src="myimages/abt.jpg" width=300 height = 200 class="img-responsive">        
          </div>
          <div class="col-sm-8" style = "font-weight : bold ; margin-top : 30px">
              Hola folks!
It looks like you are here to know us better.Online Medicine Shop is a user friendly, easy to use website where 
one can search products and book products by just fill up a simple form available on the website. 
Admin can see the product booking request and check the availability of product, and give response within 1 hour.
 To use all these features you need to login first . 
So register fast and order products.
          </div>
      </div>
  </div>
  
  </body>
  </html>