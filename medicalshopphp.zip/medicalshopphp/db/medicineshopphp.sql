


--
-- Database: `medicineshopphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
create database medicineshopphp;
use medicineshopphp;
CREATE TABLE `admin` (
  `adminname` varchar(20) NOT NULL,
  `password` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminname`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `bookingid` int(5) NOT NULL,
  `bookingdate` varchar(50) DEFAULT NULL,
  `customername` varchar(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `contact` varchar(10) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `productname` varchar(30) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `quantity` varchar(5) DEFAULT NULL,
  `total` varchar(10) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`bookingid`, `bookingdate`, `customername`, `email`, `contact`, `city`, `address`, `productname`, `price`, `quantity`, `total`, `status`) VALUES
(1, '16-04-20', 'harish', 'harish@gmail.com', '8602768216', 'Bhopal', '303 sweet homes IndrapuriIndrapuri C Sector', 'Ferrum met', '70', '3', '210', 'pending'),
(4, '16-04-20', 'harish', 'harish@gmail.com', '8602768216', 'Bhopal', '303 sweet homes IndrapuriIndrapuri C Sector', 'Amla Juice', '700', '1', '700', 'Ordered Placed');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `categoryid` int(5) NOT NULL,
  `categoryname` varchar(50) DEFAULT NULL,
  `categoryimage` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`categoryid`, `categoryname`, `categoryimage`) VALUES
(1, 'HOMEOPATHY', 'uploadimage/a1.jpg'),
(2, 'VITAMINS AND SUPPLEMENTS', 'uploadimage/a2.jpg'),
(3, 'AYURVEDA', 'uploadimage/a3.jpg'),
(4, 'HEALTH FOOD AND DRINKS', 'uploadimage/a4.jpg'),
(5, 'HEALTHCARE DEVICES', 'uploadimage/a5.jpg'),
(6, 'SKIN CARE', 'uploadimage/a6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(5) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `image` longtext DEFAULT NULL,
  `category` varchar(30) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `image`, `category`, `price`, `description`) VALUES
(1, 'Ferrum met', 'uploadimage/ferrum-metallicum-500x500.jpg', 'HOMEOPATHY', '70', 'ferrum metallic 200 c'),
(2, 'Adel 87', 'uploadimage/Adel-Pekanal.jpg', 'HOMEOPATHY', '160', 'Adel Pekanal'),
(3, 'Vitamin B Complex', 'uploadimage/vitamin b.jpg', 'VITAMINS AND SUPPLEMENTS', '567', 'Vitamin B Rich'),
(4, 'Amla Juice', 'uploadimage/amla juice.png', 'HEALTH FOOD AND DRINKS', '700', 'Vitamin C Rich'),
(5, 'Satavari', 'uploadimage/unnamed.jpg', 'HEALTH FOOD AND DRINKS', '346', 'food supplement'),
(6, 'Zandu Chyavanprash', 'uploadimage/unnamed.png', 'HEALTH FOOD AND DRINKS', '300', 'zandu product');

-- --------------------------------------------------------

--
-- Table structure for table `siteuser`
--

CREATE TABLE `siteuser` (
  `username` varchar(30) DEFAULT NULL,
  `pwd` varchar(10) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `emailid` varchar(50) NOT NULL,
  `contact` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siteuser`
--

INSERT INTO `siteuser` (`username`, `pwd`, `city`, `address`, `emailid`, `contact`) VALUES
('harish', '1234', 'Bhopal', '303 sweet homes IndrapuriIndrapuri C Sector', 'harish@gmail.com', '8602768216');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminname`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookingid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`categoryid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `siteuser`
--
ALTER TABLE `siteuser`
  ADD PRIMARY KEY (`emailid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `bookingid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `categoryid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;


