<html>
<head>
<?php include "header.php"; ?>

</head>
<body>
<?php include "nav1.php"; ?>
<style>
a {
  color:  #EE1D29;
}
a:hover {
  color: yellow;
}

.contactlink:hover {
  color: blue;
}
</style>
<div class="container text-center" style = "margin-top:50px" id="contact">
       <h1 class="text-center font-weight-bold" style="font-family : Monotype Corsiva;color : #EE1D29">Contact Us</h1>
	 <br><br><br>
      <div class="row mt-5">
          <div class="col-lg-3 col-sm-6 mydivstyle">
		  <h4><i class="fas fa-phone-square"></i> Contact</h4>
              <p class = "mt-3 text-danger font-weight-bold"><a class = "contactlink" href="tel:+91 8602768216">+91 8602768216</a></p>      
          </div>
          <div class="col-lg-3 col-sm-6 mydivstyle">
		  <h4><i class="fas fa-envelope"></i> Send Mail</h4>
              <p class = "mt-3 text-danger font-weight-bold"><a class = "contactlink" href="mailto:pankajpanjwani42@gmail.com">pankajpanjwani42@gmail.com</a></p>      
          </div>
		  <div class="col-lg-3 col-sm-6 mydivstyle">
		  <h4><i class="fas fa-address-card"></i> Office Address</h4>
              <p class = "mt-3 text-danger font-weight-bold"><a class = "contactlink" href="http://maps.google.com/maps?q=indrapuri+bhopal">Indrapuri Bhopal</a></p>      
          </div>
		  <div class="col-lg-3 col-sm-6 mydivstyle">
		  <h4><i class="far fa-clock"> </i> Office Hours</h4>
              <p class = "mt-3 text-danger font-weight-bold">9:00 AM to 7:00 PM</p>      
          </div>
      </div>
  </div>
  </body>
  </html>