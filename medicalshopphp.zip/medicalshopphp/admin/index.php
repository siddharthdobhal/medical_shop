<html>
<head>
<?php include "header.php"; ?>

</head>
<body>
<?php include "nav1.php"; ?>


<div class="container" style = "margin-top:70px">
<h2 class="text-center" style = "font-family : Monotype Corsiva ; color : red">Admin Login</h2>
<div class="form-group">
<form method = post>
<label><b>Enter UserName</b></label>
<input type = text name = adminname class="form-control">

<label><b>Enter Password</b></label>
<input type = password name = password class="form-control">
<br>
<input type = checkbox name = rem> <b>Remember Me</b>
<br>
<br>
<input type = submit name = login value = "Login" class="btn btn-primary form-control" >
</form>
</div>
</div>
</body>
</html>
<?php 
session_start();
include "dbconfigure.php";
if(isset($_POST['login']))
{
$adminname = $_POST['adminname'];
$password = $_POST['password'];
if(isset($_POST['rem']))
{
$remember = "yes";
}
else
{
$remember = "no";
}
$query = "select count(*) from admin where adminname='$adminname' and password='$password'";
$n = my_one($query);
if($n==1)
{
$_SESSION['sun']=$adminname;
$_SESSION['spwd']=$password;
  
	if($remember=='yes')
	{
		setcookie('cun',$adminname,time()+60*60*24*7);
		setcookie('cpwd',$password,time()+60*60*24*7);

	}

header("location:adminhome.php");
}
else
{
echo '<script>alert("Invalid Login Credentials,Try Again!")</script>';
}
}
?>