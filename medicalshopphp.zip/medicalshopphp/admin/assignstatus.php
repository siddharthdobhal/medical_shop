<html>
<head>
<?php include "header.php"; ?>

</head>
<body>
<?php include "nav1.php"; 
$bookingid = $_GET['id'];
?>


<div class="container" style = "margin-top:70px">
<h2 class="text-center" style = "font-family : Monotype Corsiva ; color : red">Assign Status</h2>
<div class="form-group">
<form method = post>
<label><b>Booking ID</b></label>
<input type = text value = <?php echo $bookingid;?> readonly name = adminname class="form-control">

<label><b>Status</b></label>
<select name = status class = "form-control">
<option value = "Ordered Placed">Ordered Placed</option>
 <option value = "In Delivery">In Delivery</option>
 <option value = "Delivered">Delivered</option>
</select>
<br>
<br>
<input type = submit name = submit value = "Submit" class="btn btn-primary form-control" >
</form>
</div>
</div>
</body>
</html>
<?php 
session_start();
include "dbconfigure.php";
if(isset($_POST['submit']))
{

$status = $_POST['status'];

$query = "update booking set status='$status' where bookingid=$bookingid";
$n = my_iud($query);
if($n == 1)
{
echo '<script>alert("Status Changed Successfully")</script>' ;
header("Location:viewbooking.php");
}
else
{
echo '<script>alert("Something Went Wrong!")</script>' ;
}
}
?>