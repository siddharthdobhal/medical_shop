<?php 
include "dbconfigure.php";

$id = $_GET['id'];
$query = "delete from category where categoryid=$id";

my_iud($query);
header("location:viewcategory.php");
?>