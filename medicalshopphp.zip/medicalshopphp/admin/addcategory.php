<?php 
session_start();
include "dbconfigure.php";
if(verifyuser())
{
$name = $_SESSION['sun'];
}
else
{
header("location:index.php");
}
?>
<html>
<head>
<?php include "header.php"; ?>

</head>
<body>
<?php include "nav2.php";
echo "<br>Welcome <b style = 'text-transform : capitalize ; color : blue'>$name</b>";
 ?>


<div class="container" style = "margin-top:50px">
<h2 class="text-center" style = "font-family : Monotype Corsiva ; color : red">Add New Category</h2>

<div class="form-group">
<form method = post enctype = "multipart/form-data">
<label><b>Category Name</b></label>
<input type = text name = "categoryname" class="form-control">

<label><b>Category Image</b></label>
<input type = file name = "image" class="form-control">


<br>
<input type = submit name = submit value = "Submit" class="btn btn-primary form-control" >
</form>
</div>



</div>
</body>
</html>
<?php 
if(isset($_POST['submit']))
{
$categoryname = $_POST['categoryname'];

move_uploaded_file($_FILES['image']['tmp_name'],"uploadimage/".$_FILES['image']['name']);

$categoryimage = "uploadimage/".$_FILES['image']['name'];


$query = "insert into category(categoryname,categoryimage) values('$categoryname','$categoryimage')";

$n = my_iud($query);
if($n==1)
{
echo '<script>alert("Record Saved Successfully");
window.location = "viewcategory.php";
</script>';
}
else
{
echo '<script>alert("Something went wrong,Try Again!")</script>';
}
}
?>
