<nav class="navbar navbar-expand-sm navbar-dark bg-dark pl-5">
<a class="navbar-brand">
Online Medicine Shop
</a>


<button type = button class="navbar-toggler" data-toggle="collapse" data-target="#abc">
<span class="navbar-toggler-icon"></span>
</button>


<div class="collapse navbar-collapse" id="abc" >
<ul class="navbar-nav pl-5">
<li class = "nav-item">
<a href = "adminhome.php" class="nav-link" style = "color : white"><i class="fas fa-home">&nbsp;</i>Home</a>
</li>


<li class="nav-item dropdown">
	  <a  href="#" class="nav-link dropdown-toggle" style="color:white;"  data-toggle="dropdown">Product</a>
	  
	  <div class="dropdown-menu">
	  <a class="dropdown-item" href="addproduct.php">Add Product</a>
	    <a class="dropdown-item" href="viewproduct.php">View Product</a>
	 </div>
	 </li>

	 
<li class="nav-item dropdown">
	  <a  href="#" class="nav-link dropdown-toggle" style="color:white;"  data-toggle="dropdown">Category</a>
	  
	  <div class="dropdown-menu">
	  <a class="dropdown-item" href="addcategory.php">Add Category</a>
	    <a class="dropdown-item" href="viewcategory.php">View Category</a>
	 </div>
	 </li>	 
	 



<li class = "nav-item">
<a href = "viewbooking.php" class="nav-link" style = "color : white">View Booking</a>
</li>

<li class = "nav-item">
<a href = "viewcustomer.php" class="nav-link" style = "color : white">View Customer</a>
</li>
<li class = "nav-item">
<a href = "logout.php" class="nav-link" style = "color : white">Logout</a>
</li>
</ul>
</div>

</nav>