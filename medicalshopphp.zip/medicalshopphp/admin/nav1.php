<nav class="navbar navbar-expand-sm navbar-dark bg-dark pl-5">
<a class="navbar-brand">
Online Medicine Shop
</a>


<button type = button class="navbar-toggler" data-toggle="collapse" data-target="#abc">
<span class="navbar-toggler-icon"></span>
</button>


<div class="collapse navbar-collapse" id="abc" >
<ul class="navbar-nav ml-auto">


<li class = "nav-item">
<a href = "../index.php" class="nav-link" style = "color : white"><i class="fas fa-long-arrow-alt-left"></i> BACK</a>
</li>
</ul>
</div>

</nav>