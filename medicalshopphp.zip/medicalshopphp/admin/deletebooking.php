<?php 
include "dbconfigure.php";

$id = $_GET['id'];
$query = "delete from booking where bookingid=$id";

my_iud($query);
header("location:viewbooking.php");
?>