<?php 
session_start();
include "dbconfigure.php";
if(verifyuser())
{
$name = $_SESSION['sun'];
}
else
{
header("location:index.php");
}
?>
<html>
<head>
<?php include "header.php"; ?>

</head>
<body>
<?php include "nav2.php";
echo "<br>Welcome <b style = 'text-transform : capitalize ; color : blue'>$name</b>";
 ?>


<div class="container" style = "margin-top:50px">
<h2 class="text-center" style = "font-family : Monotype Corsiva ; color : red">Add Product</h2>

<div class="form-group">
<form method = post enctype = "multipart/form-data">
<label><b>Product Name</b></label>
<input type = text name = "name" class="form-control">

<label><b>Product Image</b></label>
<input type = file name = "image" class="form-control">


<label><b>Category</b></label>
<select name = category>
<?php
$sql = "SELECT * from category";
$rs = my_select($sql);
while ($row = mysqli_fetch_array($rs)){
echo "<option value='$row[1]'>$row[1]</option>" ;
}
?>
</select>
<br>
<label><b>Price</b></label>
<input type = text name = "price" class="form-control">
<label><b>Description</b></label>
<input type = text name = "description" class="form-control">
<br>
<input type = submit name = submit value = "Submit" class="btn btn-primary form-control" >
</form>
</div>



</div>
</body>
</html>
<?php 
if(isset($_POST['submit']))
{
$name = $_POST['name'];

move_uploaded_file($_FILES['image']['tmp_name'],"uploadimage/".$_FILES['image']['name']);

$image = "uploadimage/".$_FILES['image']['name'];
$category = $_POST['category'];
$price = $_POST['price'];
$description = $_POST['description'];

$query = "insert into product(name,image,category,price,description) values('$name','$image','$category','$price','$description')";

$n = my_iud($query);
if($n==1)
{
echo '<script>alert("Record Saved Successfully");
window.location = "viewproduct.php";
</script>';
}
else
{
echo '<script>alert("Something went wrong,Try Again!")</script>';
}
}
?>
