<?php 
session_start();
include "dbconfigure.php";
if(verifyuser())
{
$name = $_SESSION['sun'];
}
else
{
header("location:index.php");
}
?>
<html>
<head>
<?php include "header.php"; ?>

</head>
<body>
<?php include "nav2.php";
echo "<br>Welcome <b style = 'text-transform : capitalize ; color : blue'>$name</b>";
 ?>


<div class="container" style = "margin-top:130px">
<div class = "row">
<div class = "col-sm-4 mydivstyle" >
<h2 style = "color : blue ; font-weight : bold ; text-align : center">Total Bookings</h2>
<h3 class= "mt-3" style = "color : green ; font-weight : bold ; text-align : center"><?php echo totalbookings();?></h2>
</div>
<div class = "col-sm-4 mydivstyle">
<h2 style = "color : blue ; font-weight : bold ; text-align : center">Total Customers</h2>
<h3 class= "mt-3" style = "color : green ; font-weight : bold ; text-align : center"><?php echo totalcustomers();?>
</div>
<div class = "col-sm-4 mydivstyle">
<h2 style = "color : blue ; font-weight : bold ; text-align : center">Total Products</h2>
<h3 class= "mt-3" style = "color : green ; font-weight : bold ; text-align : center"><?php echo totalproducts();?>
</div>
</div>
</div>
</body>
</html>
<?php 
function totalbookings()
{
$query = "select * from booking";
$rs = my_select($query);
$n = mysqli_num_rows($rs);
return $n;
}

function totalcustomers()
{
$query = "select * from siteuser";
$rs = my_select($query);
$n = mysqli_num_rows($rs);
return $n;
}

function totalproducts()
{
$query = "select * from product";
$rs = my_select($query);
$n = mysqli_num_rows($rs);
return $n;
}
?>
