<?php 
session_start();
unset($_SESSION['sun']);
unset($_SESSION['spwd']);
setcookie('cun',"",time()-60*60*24*7);
		setcookie('cpwd',"",time()-60*60*24*7);
header("location:index.php");
?>