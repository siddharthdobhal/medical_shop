<nav class="navbar navbar-expand-sm navbar-dark bg-dark pl-5">
<a class="navbar-brand">
Online Medicine Shop
</a>


<button type = button class="navbar-toggler" data-toggle="collapse" data-target="#abc">
<span class="navbar-toggler-icon"></span>
</button>


<div class="collapse navbar-collapse" id="abc" >
<ul class="navbar-nav pl-5">
<li class = "nav-item">
<a href = "customerhome.php" class="nav-link" style = "color : white"><i class="fas fa-home">&nbsp;</i>Home</a>
</li>


<li class = "nav-item">
<a href = "viewallcategories.php" class="nav-link" style = "color : white">View All Categories</a>
</li>


<li class = "nav-item">
<a href = "viewbooking.php" class="nav-link" style = "color : white">View My Booking</a>
</li>

<li class = "nav-item">
<a href = "changepassword.php" class="nav-link" style = "color : white">Change Password</a>
</li>

<li class = "nav-item">
<a href = "logout.php" class="nav-link" style = "color : white"><i class="fas fa-sign-out-alt"></i> Logout</a>
</li>
</ul>
</div>

</nav>